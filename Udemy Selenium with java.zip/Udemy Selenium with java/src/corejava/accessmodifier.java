package corejava;

public class accessmodifier {

	private String name;
	
	//default : it can be accessed throughout the package 
	void abc (){
		
	}
	
	//public : variable/method as public : then we can able to access across all the package
public void abcd(){
		name="arun";
		System.out.println(name);
	}
	

//private : you cannot access the variable & method outside the class

private void abb(){ 
	
}


//protected : variable/method as protected : then we can  able to use this variable/method in all classes within the package & only  child class can able to use this in other packages 
protected void acc(){ 
	System.out.println("protected");
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
accessmodifier obj = new accessmodifier ();
obj.abcd();

	}

}
