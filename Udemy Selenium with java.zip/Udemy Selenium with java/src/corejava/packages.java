package corejava;

import Testngbasics.basic;

public class packages {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		basic obj = new basic();
		obj.test();
	}

}
