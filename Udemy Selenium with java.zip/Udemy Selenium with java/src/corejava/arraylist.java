package corejava;
import java.util.ArrayList;

public class arraylist {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
ArrayList <String>  a = new  ArrayList();
a.add("selenium");
a.add("appium");
a.add("winappdriver");
a.get(1);
System.out.println(a.get(1));
a.remove(2);


ArrayList <Integer> a1 = new ArrayList();
a1.add(1);
a1.add(5);

System.out.println(a1.get(1));



	}

}
