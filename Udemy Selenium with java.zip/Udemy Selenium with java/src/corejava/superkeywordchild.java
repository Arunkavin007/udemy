package corejava;

public class superkeywordchild extends superkeywordparent {

	String name = "arun academy";
	
	
	public superkeywordchild() {
		super(); //this should be always be at first line
		System.out.println("child class contructor");
	}
	
	public void getstringdata() {
		
		System.out.println(name);
		System.out.println(super.name);
		
	}
	
	
public void getdata() {
		
	super.getdata();
		System.out.println("child method");
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
superkeywordchild obj = new superkeywordchild();

obj.getdata();


	}

}
