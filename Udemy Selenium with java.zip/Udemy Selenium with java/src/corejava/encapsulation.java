package corejava;

public class encapsulation {

	private String name;
	
	public String get() {
		return name;
		
	}
	
	public void Set(String newname) {
		this.name=newname;
		
		
	}
	
	public void data() {
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encapsulation ob =new encapsulation();
		ob.name="arun";
System.out.println(ob.name);
	}

}
