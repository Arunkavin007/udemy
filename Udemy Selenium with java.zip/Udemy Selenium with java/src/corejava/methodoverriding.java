package corejava;

public class methodoverriding extends inheritanceparentclass {

public void gear() {
	System.out.println("overriding");
}

public void getdata(String a) {
	System.out.println(a);
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
methodoverriding obt =  new methodoverriding();
obt.gear();

	}

}
