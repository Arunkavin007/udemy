package selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class redbus {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	
		 System.setProperty("webdriver.chrome.driver","D:/selenium/Selenium/selenium106/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	
		driver.get("https://www.redbus.in/");
		
		 
		 driver.manage().timeouts().implicitlyWait(60,TimeUnit.SECONDS);
		 driver.manage().window().maximize();
		
	     WebElement from= driver.findElement(By.id("src"));
		     from.sendKeys("Coimbatore");
		     driver.findElement(By.xpath("//*[@id=\'search\']/div/div[1]/div/ul/li[1]")).click(); 
	/*List <WebElement> lt=	driver.findElements(By.xpath("//ul[@class='autoFill homeSearch']"));
	
	for(WebElement var : lt) {
		if(var.equals("Coimbatore")) {
			
		System.out.println(var.getText());
		var.click();
		break;
		
	}*/
	
	WebElement to= driver.findElement(By.id("dest"));
    to.sendKeys("Chennai");
    driver.findElement(By.xpath("//*[@id=\'search\']/div/div[2]/div/ul/li[1]")).click();
    
    WebElement date=driver.findElement(By.id("onward_cal"));
	 date.click();
	 
	 WebElement date1=  driver.findElement(By.xpath("//td[text()='28']"));
    date1.click();
    
    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    
	 WebElement submitbutton=driver.findElement(By.id("search_btn"));
	 submitbutton.click();
	 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	 
	 List <WebElement> printbus=driver.findElements(By.xpath("//*[@class=\"travels lh-24 f-bold d-color\"]"));
	 int totalbus =printbus.size();
	  for (WebElement webElement : printbus) {
           String name = webElement.getText();
           System.out.println("Bus name is "+name);
           
/*	List <WebElement> lts=	driver.findElements(By.xpath("//ul[@class='autoFill homeSearch']"));
	
	for(WebElement vars : lts) {
		if(vars.equals("Chennai")) {
			
		System.out.println(vars.getText());
		vars.click();
		break;
		
	}
		}*/
    
	
		
		
		
	}

	}
	}
