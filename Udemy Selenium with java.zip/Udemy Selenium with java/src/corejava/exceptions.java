package corejava;


//one try can followed by multiple catch blocks

//catch should be immediate block after try

//
public class exceptions {

	
	int a=1;
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int b=7;
		
		int c=0;
		int arr [] = new int[3];
		arr [0]=5;
	    arr [1]=6;
	    arr [2]=7;
							
		
		try {
			
			
		
			//	int k=b/c;
			//	System.out.println(k);
			
			System.out.println(arr[4]);
		}
		
		catch (ArithmeticException et) {
			System.out.println("I catched the arithmetic exception");
			
		}
		catch (IndexOutOfBoundsException ets) {
			System.out.println(ets);
			System.out.println(arr[2]);
			
		}
		catch(Exception e) {
			System.out.println("I catched the error and exception");
		} 
		finally {

//this block should be executed irrespective of exception thrown or not 
System.out.println("Delete Cookies");
	}

}
}
