package corejava;

public class variablesanddatatypes{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a =1;
String word= "car";
char c = 'c';
boolean result=true;
double dec= 10.12;

System.out.println("integer is " + a );

	}	

}
