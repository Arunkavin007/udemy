package corejava;

public class inheritancechildclass extends  inheritanceparentclass {

	
	public void engine() {
	System.out.println("new engine");
	
	
	}
	
	public void colour() {
		System.out.println(colour);
		
		
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		inheritancechildclass obj = new inheritancechildclass();
		obj.colour();
		brakes();
		obj.wheel();
		
	}

}
