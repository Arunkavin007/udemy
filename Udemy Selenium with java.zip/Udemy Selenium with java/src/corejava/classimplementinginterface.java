package corejava;

public class classimplementinginterface implements centralsysteminterface, centralsysteminterface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
centralsysteminterface obj = new classimplementinginterface ();
obj.greengo();
obj.redstop();
obj.flashyellow();


classimplementinginterface obj1 = new classimplementinginterface ();
obj1.ownmethod();


centralsysteminterface2 obj2 = new classimplementinginterface ();
obj2.trains();
	}

	@Override
	public void greengo() {
		// TODO Auto-generated method stub
		System.out.println("greengo implementation");
		System.out.println(a);
	}

	@Override
	public void redstop() {
		// TODO Auto-generated method stub
		System.out.println("redstop implementation");
	}

	@Override
	public void flashyellow() {
		// TODO Auto-generated method stub
		System.out.println("flashyellow implementation");
	}

public void ownmethod() {
	System.out.println("own class implementation");

}

@Override
public void trains() {
	// TODO Auto-generated method stub
	System.out.println("interface2 implementation");
}

	

}
