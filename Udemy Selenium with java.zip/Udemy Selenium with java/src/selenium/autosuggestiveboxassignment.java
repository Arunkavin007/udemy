package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class autosuggestiveboxassignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","D:/selenium/Selenium/selenium106/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");	  
	    driver.findElement(By.id("autocomplete")).sendKeys("United", Keys.DOWN, Keys.DOWN , Keys.DOWN);  
	System.out.println(driver.findElement(By.id("autocomplete")).getAttribute("value"));
	     
	     
	     
	}

}
