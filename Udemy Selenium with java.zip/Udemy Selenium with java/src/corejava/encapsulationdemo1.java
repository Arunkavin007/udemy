package corejava;

import org.openqa.selenium.By;

public class encapsulationdemo1 {


 
	
 

private static  By loginbtn =By.id("inputUsername");

  private By loginbtn1 =By.name("inputPassword");

  private By loginbtn5 =By.className("signInBtn");

public static By getLoginbtn() {
	return loginbtn;
}

public  void setLoginbtn(By loginbtn) {
loginbtn=loginbtn;
}
	
	

}
