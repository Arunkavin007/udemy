package corejava;

public class foreachloop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String [] car = {"swift","bmw", "audi"};
		
		for(String s : car)
		{
			System.out.println(s);
		}
	}

}
