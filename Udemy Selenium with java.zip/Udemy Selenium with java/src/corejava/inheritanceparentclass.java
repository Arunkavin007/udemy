package corejava;

public class inheritanceparentclass {
	String colour = "red";
	
	public void gear() {
		System.out.println("gear core is implemented");
	}
	
	public static void brakes() {
		System.out.println("gear core is implemented");
	}
	
	public void wheel() {
		System.out.println("wheel is implemented");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
