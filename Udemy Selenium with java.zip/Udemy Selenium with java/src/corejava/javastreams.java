package corejava;


/*import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.testng.Assert;
import org.testng.annotations.Test;

 public class javastreams  {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//count the number of names starting with Alphabet A in list
		
		ArrayList<String> names = new ArrayList<String>();
		names.add("Arun");
		names.add("kavin");
		names.add("Abishek");
		names.add("pradeep");
		names.add("Ajith");
		int count= 0;
		for(int i=0;i< names.size(); i++)
		{
			String name = names.get(i);
			if(name.startsWith("A")) {
				count++;
			}
		}
		System.out.println(count); 
		
	} 
	
		@Test
		public void streamFilter(){
			
		ArrayList<String> names = new ArrayList<String>();
		names.add("Arun");
		names.add("kavin");
		names.add("Abishek");
		names.add("pradeep");
		names.add("Ajith");
		long name= names.stream().filter(s ->s.startsWith("A")).count();
		System.out.println(name); 
		
	long cou= Stream.of("Arun","kavin","Abishek","Ajith").filter(s->
		{
			s.startsWith("A");
			return true;
		}).count();
		System.out.println(cou);
		
		names.stream().filter(s->s.length()>4).forEach(s->System.out.println(s));
		//names.stream().filter(s->s.length()>4).limit(1).forEach(s->System.out.println(s));
		
		
	}
	
		@Test
		public void streammap(){	
			
			ArrayList<String> names2 = new ArrayList<String>();
			names2.add("Arun");
			names2.add("kavin");
			names2.add("Abishek");
			names2.add("pradeep");
			names2.add("Ajith");
			
			//Stream.of("Arun","kavin","Abishek","Ajith").filter(s->s.endsWith("n")).map(s->s.toUpperCase()).forEach(s->System.out.println(s));
Stream.of("Arun","kavin","Abishek","Ajith").map(s->s.toUpperCase()).forEach(s->System.out.println(s));
			
List<String> names1 = Arrays.asList("Arun","kavin","Abishek","Ajith");
names1.stream().filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.println(s));

Stream<String>  newstream =Stream.concat(names2.stream(), names1.stream());
//newstream.sorted().forEach(s->System.out.println(s));
boolean stream = newstream.anyMatch(s->s.equalsIgnoreCase("Arun"));
System.out.println(stream);
Assert.assertTrue(stream);



		} 
		
		@Test
		public void collect() {
			
		List<String> ls =	Stream.of("Arun","kavin","Abishek","Ajith").filter(s->s.endsWith("n")).map(s->s.toUpperCase()).collect(Collectors.toList());
		System.out.println(ls.get(0));
		
		List<Integer> nt =	 Arrays.asList(3,4,9,6,7);
 nt.stream().distinct().forEach(s->System.out.println(s));
	List<Integer> list	= nt.stream().distinct().sorted().collect(Collectors.toList());
		System.out.println(list.get(2));
		} 
		
		//@Test
		public void practice() {
		long na	= Stream.of("tamil","earun","rarun","gokul").filter(s->s.equalsIgnoreCase("rarun")).count();
		System.out.println(na);
		}
		
		} */
		
	


