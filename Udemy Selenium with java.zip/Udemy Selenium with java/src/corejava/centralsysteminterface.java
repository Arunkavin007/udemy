package corejava;

public interface centralsysteminterface {

	public int a=5;
	public void greengo();
	public void redstop();
	public void flashyellow();
	}
