package corejava;

public class acessmodifier2 {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
accessmodifier ogg = new accessmodifier();
ogg.acc();
	}

}
