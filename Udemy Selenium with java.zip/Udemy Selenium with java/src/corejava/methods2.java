package corejava;

public class methods2 {

	public void methodfromotherclass()

	{

	System.out.println ("method from other class");
    

	}
	
	
	public static  void methodfromotherclass1()

	{

	System.out.println ("static method from other class");
    

	}
}
