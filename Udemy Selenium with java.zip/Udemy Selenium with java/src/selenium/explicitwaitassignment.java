package selenium;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class explicitwaitassignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     WebDriverWait wait = new WebDriverWait(driver,5);
	     
		driver.get("https://rahulshettyacademy.com/loginpagePractise");
		driver.findElement(By.id("username")).sendKeys("rahulshettyacademy");
		driver.findElement(By.id("password")).sendKeys("learning");
		
		//css selector index type //tagname.classname:nth-child(i)
		
		//driver.findElement(By.cssSelector(".customradio:nth-child(2)")).click();
		
		driver.findElement(By.xpath("(//span[@class='checkmark'])[2]")).click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.id("okayBtn")));
		driver.findElement(By.id("okayBtn")).click();
		WebElement dropdown = driver.findElement(By.cssSelector("select[data-style*='btn-info']"));
		Select obj = new Select (dropdown);
		obj.selectByVisibleText("Consultant");
		driver.findElement(By.id("terms")).click();
		driver.findElement(By.id("signInBtn")).click();
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='btn btn-info']")));	
	List<WebElement> cartlist= 	driver.findElements(By.xpath("//button[@class='btn btn-info']"));
	for (int i=0; i<cartlist.size(); i++) {
		cartlist.get(i).click();
	}
	driver.findElement(By.partialLinkText("Checkout")).click();
		//driver.quit();
	
	}

}
