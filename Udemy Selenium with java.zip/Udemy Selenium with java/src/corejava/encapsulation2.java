package corejava;

public class encapsulation2 {

	
	

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		encapsulation att = new encapsulation();
		att.Set("Arun");
		System.out.println(att.get());
		
	}

}
