package corejava;

public class methodandfunctionoverloading {
	
//argument count should be different or argument data type should be different
	
	public void getdata(int a) {
		System.out.println(a);
	}
	
public void getdata(int a, int b) {
	System.out.println(a);
	}

public void getdata(String a) {
	System.out.println(a);
}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 methodandfunctionoverloading obj = new  methodandfunctionoverloading();
		 obj.getdata(10);
		 obj.getdata(20, 30);
		 obj.getdata("arun");
	}

}
