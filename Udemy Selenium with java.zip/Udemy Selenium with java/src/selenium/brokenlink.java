package selenium;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class brokenlink {

	public static void main(String[] args) throws MalformedURLException, IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     driver.get("http://qaclickacademy.com/practice.php");
	     
	     //broken url
	     //java methods will call URL's and gets you the status code
	      //if status code >400 then that url is not working-> link which tied to url is broken

         //a[href*='soapui']
//valid url -status-200
         driver.get("https://rahulshettyacademy.com/AutomationPractice/");
         
 List <WebElement> list = driver.findElements(By.cssSelector("li[class=\"gf-li\"] a"));   
 
 SoftAssert a = new SoftAssert();
 
 for(WebElement link : list)
 {
	String urllist= link.getAttribute("href");
	HttpURLConnection conn2 = (HttpURLConnection)new URL(urllist).openConnection();
	conn2.setRequestMethod("HEAD");
	conn2.connect();
	int response2 =conn2.getResponseCode();
	System.out.println(response2);
	a.assertTrue(response2<400,"The Link with Text " + link.getText()+ " is broken with code " + response2);

	
 }
 a.assertAll();
	
/*if(response2>400)
	{
		System.out.println("The Link with Text " + link.getText()+ " is broken with code " + response2);
		Assert.assertTrue(false);
		
 } */
 
 
         
 /*  String  url  = driver.findElement(By.cssSelector("a[href*='soapui']")).getAttribute("href");
 HttpURLConnection conn = (HttpURLConnection)new URL(url).openConnection();
conn.setRequestMethod("HEAD");
conn.connect();
int response =conn.getResponseCode();
System.out.println(response);

//broken url- status-404
String  brokenurl  = driver.findElement(By.cssSelector("a[href*='brokenlink']")).getAttribute("href");
HttpURLConnection conn1 = (HttpURLConnection)new URL(brokenurl).openConnection();
conn1.setRequestMethod("HEAD");
conn1.connect();
int response1 =conn1.getResponseCode();
System.out.println(response1); */

}
	}
