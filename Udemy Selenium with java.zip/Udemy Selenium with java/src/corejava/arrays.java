package corejava;

public class arrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] arr = new int[6];
		arr[0] =1;
		arr[1]=2;
		arr[2]=3;
		arr[3]=4;
		arr[4]=5;
		arr[5]=6;  
		
		System.out.println(arr[2]);
		
		
		int [] arr1= {1,2,3,4,5,6};
		System.out.println(arr1[2]);
		
	}

}
