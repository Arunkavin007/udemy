package corejava;

public abstract class abstractionparentclass {


public static void engine() {
	
	System.out.println("Engine guidelines");
}

public void enginesafety() {
	
	System.out.println("follow safety guidelines");
}

public abstract void bodycolour();

	}


