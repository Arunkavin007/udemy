package corejava;

public class finalkeyword {

	
	 final void getdata() {
		System.out.println("parent");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
final int a=1; //constant variables

finalkeyword obj = new finalkeyword();




	}

}
