package corejava;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashmapandHashtableimplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<Integer,String> obj = new HashMap<Integer,String>();
		
		obj.put(0, "Arun");
		
		obj.put(1, "Kavin");
		
	    obj.put(2,"nsak");
		
	    obj.put(3,"nsk");
	    
	    obj.put(4,"");
	    
	  
	    
	    System.out.println(obj.get(2));
	    
	    obj.remove(3);
	    
	    System.out.println(obj.get(3));
	 
	  /*HashMap<String ,String> obj1 = new HashMap<String,String>();
	    obj1.put("name","Arun" );
	    System.out.println(obj1.get("name"));*/
	    
	  Set mp = obj.entrySet(); 
	  
	  Iterator i =mp.iterator();
	  
	  while(i.hasNext()) {
	    
		  System.out.println(i.next());
		//Map.Entry  en =(Map.Entry)i.next();
		//System.out.println(en.getValue());
		//System.out.println(en.getKey());
		
	}
	  
	  
	  //HashTable
	  
	  Hashtable<String,String> tab = new Hashtable<String,String>();
	  
	  

}
}
