package selenium;

import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class WebtableSortingusingStreams {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     driver.get("https://rahulshettyacademy.com/seleniumPractise/#/offers");
		
	     //Click on column
	     driver.findElement(By.xpath("//tr/th[1]")).click();
	     
	     //capture all webelements into list 
	List <WebElement>   list   = driver.findElements(By.xpath("//tr/td[1]"));
	
	//capture  text of all webelements into new (originallist) 
	//list.stream().map(s->s.getText()).forEach(s->System.out.println(s));
/* List <String> originallist	= list.stream().map(s->s.getText()).collect(Collectors.toList());

//sort on original list 
  List <String> sorted =originallist.stream().sorted().collect(Collectors.toList());
Assert.assertTrue(originallist.equals(sorted)); */


//scan the column with gettext print the price of rice
	List <String> price;
	do
	{
		List <WebElement>   list1   = driver.findElements(By.xpath("//tr/td[1]"));
  price = list1.stream().filter(s->s.getText().contains("Rice")).map(s->getprice(s)).collect(Collectors.toList());
price.forEach(s->System.out.println(s));

// list.stream().filter(s->s.getText().contains("Beans")).map(s->getprice(s)).forEach(s->System.out.println(s));

if(price.size()<1)
{
	driver.findElement(By.cssSelector("[aria-label='Next']")).click();
}
	}while(price.size()<1);
	
	}
	
private static  String getprice(WebElement s)
{
	
	String pri = s.findElement(By.xpath("following-sibling::td[1]")).getText();
	return pri ;
	
	
	}






	
}
