package corejava;

public class methods {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		methods d = new methods();

		d.getData();
		d.getData1();
		System.out.println(d.getData1());
		d.getData2();
		System.out.println(d.getData2());
		
		methods2 d1 = new methods2();

		d1.methodfromotherclass();
		
		getData5();
		
		methods2.methodfromotherclass1();
		d.getData8();

		}



		public void getData()

		{

		System.out.println ("hello world");


		}
		
		public String getData1()

		{

		System.out.println ("hello world");
        return "test";

		}
		
		public int getData2()

		{

		System.out.println ("hello world");
        return 100;
        

		}
		
		public static void getData5()

		{

		System.out.println ("static ");
		getData6();
		}
		
		
		public static void getData6()

		{

		System.out.println ("static1 ");
		
		}
		public void getData8()

		{

		System.out.println ("static10 ");
		getData9();
		getData5();
		}
		
		public void getData9()

		{

		System.out.println ("static1 ");
		
		}




}
