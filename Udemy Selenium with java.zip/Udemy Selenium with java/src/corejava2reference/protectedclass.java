package corejava2reference;

import corejava.accessmodifier;

public class protectedclass extends accessmodifier {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	
	protectedclass obj = new protectedclass();
	obj.acc();
	obj.abcd();
	}

}
