package corejava;

public class multidimensionalarrayexamplecisco {

	public static void main(String[] args) {
		
		
	//	step1: find the minimum number of the matrix
		
		//step2 : identify the column of the minimum number
		
		//step3 : identify the maximum number of the column 
		
		
		//2 4 5
		
		//3 0 7
		
		//1 2 9
		
		int mincolumn=0;
		
int abc [][] = {{2,4,5},{6,3,7},{0,1,9}};
		
		int min= abc [0][0];
		
		
		for(int i=0;i<3;i++) {
			for (int j=0;j<3;j++) {
				if (abc[i][j]<min) {
					min=abc[i][j];
					mincolumn=j;
				}
			}
			
		}
		
		int k=0;
		int max =abc [0][mincolumn];
		while(k<3) {
			if(abc[k] [mincolumn]>max) {
				max=abc [k] [mincolumn];
				
			}
			k++;
			
		}
		System.out.println(max);
		
	}

}
