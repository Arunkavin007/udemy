package corejava;

public class thisdemo {

	
	int a=2;
	
	public void getdata() {
		
		int a=3;
		int b= a+ this.a;
		System.out.println(a); //this refers to current object
		System.out.println(this.a);
		System.out.println(b);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
thisdemo obj=new thisdemo();
obj.getdata();

	}

}
