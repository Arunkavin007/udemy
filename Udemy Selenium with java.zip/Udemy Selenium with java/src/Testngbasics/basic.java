package Testngbasics;

import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class basic {
	@AfterSuite
	public void basic6() {
		System.out.println("executiondone");
		}	
	@AfterTest
	public void testafter() {
		System.out.println("completed");
	}
	
	@Test(groups= {"Smoke"})
	public void test() {
		
		System.out.println("test1");
	}
	
	@Parameters({"url"})
	@Test
	public void testmethod(String urlname) {
		
		System.out.println("test2");
		System.out.println(urlname);
		Assert.assertTrue(false);
	}
	@BeforeTest
	public void testbefore() {
		System.out.println("execute1");
	}
	
	}


