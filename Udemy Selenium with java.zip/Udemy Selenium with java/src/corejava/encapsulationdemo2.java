package corejava;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;



public class encapsulationdemo2  {
	
	public static void main(String[] args) {
		
		 System.setProperty("webdriver.chrome.driver","D:/selenium/Selenium/chrome98/chromedriver.exe");
	    WebDriver driver = new ChromeDriver(); 
	    driver.get("https://rahulshettyacademy.com/locatorspractice/");
	    driver.findElement(encapsulationdemo1.getLoginbtn()).sendKeys("arun");
	    
	    
	 
			
	
	}

	
	
}