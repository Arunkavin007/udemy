package selenium;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class scope {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
		driver.get("http://qaclickacademy.com/practice.php");
		
		//count the links on the webpage
		
		System.out.println(driver.findElements(By.tagName("a")).size());
		WebElement footerdriver = driver.findElement(By.id("gf-BIG")); //Limiting the WebDriver scope
		
		//count the links on the footer part in the web page
		System.out.println(footerdriver.findElements(By.tagName("a")).size());
		
	  WebElement  columndriver =  footerdriver.findElement(By.xpath("//table/tbody/tr/td[1]/ul")); //Limiting the WebDriver scope
	  
		//count the links on the first column in the footer part of webpage
	  System.out.println(columndriver.findElements(By.tagName("a")).size());
	 List<WebElement> firstcolumn = columndriver.findElements(By.tagName("a"));
	 
	  //Click on the links in the first column in the footer part of webpage and open in new tab
	  
	  for (int i=1; i<firstcolumn.size(); i++) {
		  String clickonlinkintabs = Keys.chord(Keys.CONTROL,Keys.ENTER);
		  columndriver.findElements(By.tagName("a")).get(i).sendKeys(clickonlinkintabs);
	  }
	  
   Set <String> windows	=  driver.getWindowHandles(); //4
   Iterator <String> win = windows.iterator();
   
   while(win.hasNext())
   {
		driver.switchTo().window(win.next());
		System.out.println(driver.getTitle());
	  } 
		  
	     
	  
			
		
	  
	}

}

