package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class staticdropdown {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     driver.get("https://rahulshettyacademy.com/dropdownsPractise/#");
	     //Dropdown with select tag
	     WebElement staticdropdown= driver.findElement(By.id("ctl00_mainContent_DropDownListCurrency"));
	     Select obj= new Select(staticdropdown);
	     obj.selectByIndex(3);
	     System.out.println(obj.getFirstSelectedOption().getText());
	     obj.selectByValue("INR");
	     System.out.println(obj.getFirstSelectedOption().getText());
	     obj.selectByVisibleText("INR");
	     System.out.println(obj.getFirstSelectedOption().getText());
	     
	   
	     driver.findElement(By.id("divpaxinfo")).click();

	     Thread.sleep(2000L);

	     /*int i=1;

	  while(i<5)

	  {

	  driver.findElement(By.id("hrefIncAdt")).click();//4 times

	  i++;

	  }*/

	     System.out.println(driver.findElement(By.id("divpaxinfo")).getText());

	  for(int i=1;i<5;i++)

	  {

	  driver.findElement(By.id("hrefIncAdt")).click();

	  }

	  driver.findElement(By.id("btnclosepaxoption")).click();

	  Assert.assertEquals(driver.findElement(By.id("divpaxinfo")).getText(), "5 Adult");

	  System.out.println(driver.findElement(By.id("divpaxinfo")).getText());
	     
	}

}
