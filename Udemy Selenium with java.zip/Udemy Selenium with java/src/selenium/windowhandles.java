package selenium;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class windowhandles {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     driver.get("https://rahulshettyacademy.com/loginpagePractise/#");
	     driver.findElement(By.cssSelector(".blinkingText")).click();
	  Set <String> window= driver.getWindowHandles(); //[parentid,childid,subchildid]
	 Iterator<String> it= window.iterator();
	 String	parent= it.next();
	  System.out.println(parent);
    String	child= it.next();
    System.out.println(parent);
	   driver.switchTo().window(child); 
	   System.out.println(driver.findElement(By.cssSelector(".im-para.red")).getText());
	String emailid =   driver.findElement(By.cssSelector(".im-para.red")).getText().split("at")[1].trim().split("with")[0];
	driver.switchTo().window(parent);
	driver.findElement(By.id("username")).sendKeys(emailid);
	driver.close();
	}

}
