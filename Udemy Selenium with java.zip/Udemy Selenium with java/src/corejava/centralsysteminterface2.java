package corejava;

public interface centralsysteminterface2 {
public void trains();
}
