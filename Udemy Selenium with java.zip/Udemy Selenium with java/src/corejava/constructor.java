package corejava;

public class constructor {

	
	public constructor() {
		System.out.println("I'm  a constructor");
	} 
	
	//parameterized constructor
	
	public constructor(int a, int b) {
		int total;
		total=a+b;
		System.out.println("I'm  a parameterized constructor");
		System.out.println(total);
	}
	
	public constructor(String str ) {
		System.out.println(str);
	} 
	
	public void getdata() {
		System.out.println("I'm in a method");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
constructor obj = new constructor();

constructor obj1 = new constructor(4,5);

constructor obj2 = new constructor("hello");


//compiler will call implicit constructor if you have not define any constructor block 
//whenever you create an object constructor is called 

//block of code will be executed when ever an object is created 


	}

}
