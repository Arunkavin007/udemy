package corejava;

public class superkeywordparent {
	
	String name= "arun";
	
	
public superkeywordparent() {
		System.out.println("parent class contructor");
	}

	public void getdata() {
		System.out.println("parent method");
	}
	
}
