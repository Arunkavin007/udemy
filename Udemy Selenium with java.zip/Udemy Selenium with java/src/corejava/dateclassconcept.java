package corejava;

import java.text.SimpleDateFormat;
import java.util.Date;

public class dateclassconcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//current date //current time
		
		Date dt = new Date ();
		
		
		//mm//dd//yyyy //HH:MM:SS
		SimpleDateFormat sdf = new SimpleDateFormat("d/M/yyy");
		SimpleDateFormat sdf1 = new SimpleDateFormat("d/M/yyy  hh:mm:ss");
		
		System.out.println(sdf.format(dt));
		System.out.println(sdf1.format(dt));
		System.out.println(dt.toString());
	}

}
