package selenium;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		 System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     
	     driver.get("https://www.cleartrip.com/");
	   
	     driver.manage().window().maximize();
	     
	WebElement  adult=  driver.findElement(By.xpath("(//select[@class='bc-neutral-100 bg-transparent'])[1]"));
	    Select obj = new Select(adult);
	    obj.selectByIndex(1);
	    WebElement   children =  driver.findElement(By.xpath("(//select[@class='bc-neutral-100 bg-transparent'])[2]"));
	    Select obj1 = new Select(children);
	    obj1.selectByValue("5");
	    WebElement    Infants =  driver.findElement(By.xpath("(//select[@class='bc-neutral-100 bg-transparent'])[3]"));
	    Select obj2 = new Select(Infants);
	    obj2.selectByValue("1"); 
	   driver.findElement(By.partialLinkText("Class of travel")).click();
	   driver.findElement(By.cssSelector("input[placeholder='Airline name']")).sendKeys("Indigo"); 
	  driver.findElement(By.xpath("(//div[@class='col flex flex-middle'])[5]")).click(); 
	  Thread.sleep(5000);
	 //  System.out.println(driver.findElement(By.xpath("//div[@class='col-24']")).getText());
	    driver.quit(); 
	}
}
