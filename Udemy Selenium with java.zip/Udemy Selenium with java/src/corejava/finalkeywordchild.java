package corejava;

public class finalkeywordchild extends finalkeyword {

	
	/* public void getdata() {
		System.out.println("final");
	} */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
finalkeywordchild obj = new finalkeywordchild();
obj.getdata();
	}

}
