package corejava;

import java.util.ArrayList;

public class PracticeamazonInterviewPrintingUniqueNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {4,5,4,5,6,3,4,6,5};
		
		//4-3 5-3 6-2 3-1
		
		//Empty ArrayList 
		
		
		ArrayList <Integer> al= new ArrayList<Integer>();
		
		
		 
		for(int i=0; i<a.length; i++) {
			
			int k=0;
			if(!al.contains(a[i])){
				al.add(a[i]);
				k++;
				
				for(int j=i+1; j<a.length; j++) {
					if(a[i]==a[j]) {
					k++;	
					}
					
				}
				System.out.println(a[i]);
				System.out.println(k);
				
			}
			
		}
		
		
		
		
	}

}
