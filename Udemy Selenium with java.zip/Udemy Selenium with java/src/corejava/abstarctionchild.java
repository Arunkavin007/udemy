package corejava;

public class abstarctionchild extends abstractionparentclass{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		abstarctionchild obj = new abstarctionchild();
		engine();
		obj.enginesafety();
		obj.bodycolour();
		
	}

	@Override
	public void bodycolour() {
		// TODO Auto-generated method stub
		System.out.println("red colour");
		
	}

}
