package corejava;

public class Arraycorejava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String [] b= new String[6]; //declaring an array & allocating memory for values
		
		b [0] ="arun"; 
		b [1] ="kavin"; 
		b [2] ="nsak"; 
		b [3] ="ak"; 
		b [4] ="nak"; 
		b [5] ="vak";
		
		System.out.println(b[1]);
	/*	for (int i=0; i<b.length; i++) {
			System.out.println(b[i]);
		}
		
		int[]  a= {1,2,3,4};
		for (int i=0; i<a.length; i++) {
			System.out.println(a[i]);
		} */
		

	}

}
