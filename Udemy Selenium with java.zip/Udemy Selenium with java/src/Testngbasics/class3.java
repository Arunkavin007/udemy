package Testngbasics;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class class3 {
	@BeforeClass
	public void bclass() {
		System.out.println("bclass");
	}
	@AfterTest
	public void testafter() {
		System.out.println("completed");
	}
	@BeforeMethod
	public void web() {
		System.out.println("webbefore");
	}
	
	@Parameters({"rl","nsk"})
	@Test(groups= {"Smoke"})
	public void weblogin(String rlt, String nsk) {
		System.out.println("web");
		System.out.println(rlt);
		System.out.println(nsk);
	}
	@AfterMethod
	public void web2() {
		System.out.println("webafter");
	}
	@Test(enabled=false)
	public void Mobilelogin() {
		System.out.println("mobile ");
	}
	
	@Test(dependsOnMethods=("weblogin"))
	public void Mobilesignin() {
		System.out.println("mobile");
	}
	@Test(dataProvider="getdata")
	public void test(String username, String password) {
		System.out.println(username);
		System.out.println(password);
	}
	@BeforeTest
	public void testbefore() {
		System.out.println("execute");
	}
	@AfterClass
	public void aclass() {
		System.out.println("bclass");
	}
	
	@DataProvider
	public Object[][] getdata() {
		//1st combination- username , password
		//multiple combination
		
		Object[][] data = new Object[3][2];
		data[0][0]= "firstusername";
		data[0][1]= "firstpassword";
		data[1][0]= "secondusername";
		data[1][1]= "secondpassowrd";
		data[2][0]= "thirdusername";
		data[2][1]= "secondpassowrd";
		return data;
	}
}
