package Testngbasics;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class globalvariables {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
Properties proper= new Properties();
FileInputStream fis = new FileInputStream("C:\\Users\\Hp\\eclipse-workspace\\Udemy Selenium with java\\src\\Testngbasics\\data.properties");
proper.load(fis);
System.out.println(proper.getProperty("browser"));
System.out.println(proper.getProperty("url"));
proper.setProperty("browser", "firefox");
System.out.println(proper.getProperty("browser"));
FileOutputStream fos = new FileOutputStream("C:\\Users\\Hp\\eclipse-workspace\\Udemy Selenium with java\\src\\Testngbasics\\data.properties");
proper.store(fos, null);
	}

}
