package corejava;

import java.util.HashSet;
import java.util.Iterator;

public class setInterfacewithhashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
//HashSet treeSet linkedHashset implements set interface
		
	//set interface does not accept duplicate values	
		
		//there is no guarantee elements stored in sequential order.. it may stored in random order 
		
		HashSet<String> hs = new HashSet<String>();
		
		hs.add("uae");
		hs.add("uk");
		hs.add("India");
		hs.add("India");
		hs.add("sri");
		hs.add("usa");
		System.out.println(hs);
		//hs.remove("India");
		System.out.println(hs);
		System.out.println(hs.isEmpty());
		System.out.println(hs.size());
		
		//Iterator interface
	Iterator<String> i=hs.iterator();
	
	//System.out.println(i.next());
	//System.out.println(i.next());
	
	while (i.hasNext()) {
		System.out.println(i.next());
	}
		
		
	
		
		
		
		
	}

}
