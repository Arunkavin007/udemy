package corejava;

public class staticvariable {

	
	String name; //Instance variable
	String  address;
	static String City="Bengaluru"; //class variables
	
	static int i=0;

	

	
	static{  //static blocks
		i=0;
		City="Bengaluru";
		
	}
	
	public staticvariable(String name, String address) {
		this.name=name;
		this.address=address;
		i++;
		System.out.println(i);
	}
	
	public void getaddress() {
		System.out.println(address+ " "+City);
		 i=i+10;
		 System.out.println(i);
	}
	
	
	public static void getcity() {
		System.out.println(City);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
staticvariable obj = new staticvariable("arun","puliyur");

staticvariable obj1 = new staticvariable("kavin","karur");

obj.getaddress();

obj1.getaddress();

staticvariable.getcity();

	}

}
