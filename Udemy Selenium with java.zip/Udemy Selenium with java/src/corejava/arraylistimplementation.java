package corejava;

import java.util.ArrayList;

public class arraylistimplementation {
	
	//all the classes implements ListInterface will  accept duplicate values
	
	//ArrayList, LinkedList, Vector - Implementing ListInterface
	
	//Array has Fixed Size & arrayList can grow as dynamically
	
	//In arrayList, you can access & insert any values in any Index
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> obj = new ArrayList<String>();
obj.add("arun");
obj.add("kavin");
obj.add("kavin");
System.out.println(obj);
obj.add(0, "nsak");
System.out.println(obj);
/*obj.remove(1);
obj.remove("kavin");
System.out.println(obj);*/

System.out.println(obj.get(0));

//testing 


System.out.println(obj.contains("testing"));

System.out.println(obj.indexOf("kavin"));
System.out.println(obj.isEmpty());
System.out.println(obj.size());






	}

}
