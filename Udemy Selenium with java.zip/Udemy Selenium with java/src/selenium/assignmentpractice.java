package selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.w3c.dom.Text;

public class assignmentpractice {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     driver.get("http://qaclickacademy.com/practice.php");
        driver.findElement(By.xpath("//*[@id='checkbox-example']/fieldset/label[2]/input")).click();
    String option  = driver.findElement(By.xpath("//*[@id='checkbox-example']/fieldset/label[2]")).getText();
  WebElement dropdown=  driver.findElement(By.id("dropdown-class-example"));
  Select drop = new Select(dropdown);
  drop.selectByVisibleText(option); 
  driver.findElement(By.id("name")).sendKeys(option);
  driver.findElement(By.id("alertbtn")).click();
 String alert =  driver.switchTo().alert().getText();
if(alert.contains(option)) {
	System.out.println("Alert Message Success");
}
else 
{
  System.out.println("wrong execution");
}
        
	     
	}

}
