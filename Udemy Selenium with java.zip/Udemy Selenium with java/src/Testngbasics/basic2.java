package Testngbasics;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

public class basic2 {
	
	@Test(timeOut=4000)
	public void basic2() {
System.out.println("basic2");
}
	@BeforeSuite
	public void basic4() {
		System.out.println("executionstarted");
		}	
}
