package selenium;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class arraywithcart {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		 System.setProperty("webdriver.chrome.driver","C:/Selenium/chrome 93/chromedriver.exe");
	     WebDriver driver = new ChromeDriver(); 
	     
	     //Implicitwait
	     driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	     
	     
	     //Explicitwait
	     
	   //  WebDriverWait w =new WebDriverWait(driver,5);
	 	
	     String [] itemsneeded= {"Brocolli","Cucumber","Almonds","Carrot"};
	     
		driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
	
		additems(driver, itemsneeded);
		
		driver.findElement(By.cssSelector("img[alt='Cart']")).click();
		Thread.sleep(10);
		driver.findElement(By.xpath("//button[text()='PROCEED TO CHECKOUT']")).click();

	//	w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".promoCode")));
	
		
		driver.findElement(By.cssSelector(".promoCode")).sendKeys("rahulshettyacademy");
		driver.findElement(By.cssSelector("button.promoBtn")).click();
		
	
	//	w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.cssSelector(".promoInfo")));
		System.out.println(driver.findElement(By.cssSelector(".promoInfo")).getText());


		
	}
		
	
	public static void additems(WebDriver driver,String [] itemsneeded ) {
	
		int j=0;
		
List<WebElement> product= driver.findElements(By.cssSelector("h4.product-name"));

for (int i=0; i<product.size();i++)
	
{
	String[] name= product.get(i).getText().split("-");
	String formated= name[0].trim();
	//convert Array into Arraylist  for each search 
	
List itemslist = Arrays.asList(itemsneeded);

if(itemslist.contains(formated))
{
	j++;
 driver.findElements(By.xpath("//div[@class='product-action']//button")).get(i).click();
if(j==itemsneeded.length)
{
	break;
}
}

}

	}
}
